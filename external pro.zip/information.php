<?php
$Name = $_POST['Name'];
$Phoneno = $_POST['Phoneno'];               
$Bank_accno  = $_POST['Bank_accno'];
$income = $_POST['income'];
$expenditure = $_POST['expenditure'];
$target_savings = $_POST['target_savings'];
$conn = new mysqli('localhost','root','','information');
if($conn->connect_error){
    die('Connection Failed : ' .$conn->connect_error);
}
else {
    $stmt = $conn->prepare("insert into details(Name,Phoneno,Bank_accno,income,expenditure,target_savings)
                           values(?,?,?,?,?,?)");
    $stmt->bind_param("ssssss",$Name,$Phoneno,$Bank_accno,$income,$expenditure,$target_savings);
    $stmt->execute();
    echo "registration successful";
    $stmt->close();
    $conn->close();

}
?>